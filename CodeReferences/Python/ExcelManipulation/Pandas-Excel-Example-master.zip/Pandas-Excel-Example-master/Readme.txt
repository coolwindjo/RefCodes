Yesterday, helped a coworker make use of Python & the Pandas library
to read and write Excel documents. Pretty easy stuff with Pandas, but
there are some big changes between versions of Pandas in the syntax
you use. The Enthought Python distribution I used comes with version
0.14.1 of Pandas. 
