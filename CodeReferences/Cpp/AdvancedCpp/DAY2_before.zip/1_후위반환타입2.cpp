#include <iostream>

int Mul(int a, int b)
{
	return a * b;
}
int main()
{
	std::cout << Mul(1, 3) << std::endl;
}