#include <iostream>

class A
{
};

class B
{
public:
	virtual void foo() {}
};
int main()
{

}