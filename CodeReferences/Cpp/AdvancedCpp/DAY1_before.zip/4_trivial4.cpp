#include <iostream>
#include <thread>

int obj = 0;

int main()
{
	int n = obj;
}
